
package quickchatapp;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import javax.swing.JOptionPane;



public class Message {
    private static int totalMessages = 0;
    private static int messageNumber = 0;
    private static String[] sentMessages = new String[100];
    private String messageID;
    private String recipient;
    private String message; 
    private static String[] messageIDs = new String[100];
    private static String[] messageHashes = new String[100];
    private static String[] recipients = new String[100];
    
    public Message(String recipient, String message) {
        this.messageID = String.format("%010d", new Random().nextInt(1000000000));
        this.recipient = recipient;
        this.message = message;
    }


      public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    public boolean checkRecipientCell() {
        return recipient.startsWith("+27") && recipient.length() == 12 && allDigits(recipient.substring(3));
    }

    private boolean allDigits(String s) {
        for (char c : s.toCharArray()) {
            if (!Character.isDigit(c)) return false;
        }
        return true;
    }

    public String createMessageHash() {
        String[] words = message.split(" ");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : first;
        return messageID.substring(0, 2) + ":" + messageNumber + ":" + first.toUpperCase() + last.toUpperCase();
    }

    public String sendMessageOption(int option) {
        switch (option) {
           case 1:
        totalMessages++;
        messageNumber++;
        sentMessages[totalMessages - 1] = toString();
        messageIDs[totalMessages - 1] = messageID;
        messageHashes[totalMessages - 1] = createMessageHash();
        recipients[totalMessages - 1] = recipient;
        return "Message successfully sent.";
        case 2:
            return "Message disregarded.";
        case 3:
            storeMessage();
            return "Message successfully stored.";
        default:
            return "Invalid option.";
        }
    }

    public void storeMessage() {
        try (FileWriter file = new FileWriter("messages.txt", true)) {
           file.write("Message ID: " + messageID + "\n");
           file.write("Message Hash: " + createMessageHash() + "\n");
           file.write("Recipient: " + recipient + "\n");
           file.write("Message: " + message + "\n");
           file.write("-------------------------\n");
       } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Error storing message: " + e.getMessage());
      }
    }

    public static String printMessages() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < totalMessages; i++) {
            sb.append(sentMessages[i]).append("\n");
        }
        return sb.toString();
    }

    public static int returnTotalMessages() {
        return totalMessages;
    }

    // Get the longest message
     public static String getLongestMessage() {
        String longest = "";
       for (int i = 0; i < totalMessages; i++) {
         if (sentMessages[i] != null && sentMessages[i].length() > longest.length()) {
             longest = sentMessages[i];
         }
      }
           return longest;
         }

       // Search by Message ID
        public static String searchByMessageID(String id) {
            for (int i = 0; i < totalMessages; i++) {
          if (messageIDs[i] != null && messageIDs[i].equals(id)) {
              return sentMessages[i];
          }
       }
          return "Message ID not found.";
    }

         // Search all messages sent to a recipient
       public static String searchByRecipient(String number) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < totalMessages; i++) {
           if (recipients[i] != null && recipients[i].equals(number)) {
              result.append(sentMessages[i]).append("\n\n");
         }
      }
         return result.length() > 0 ? result.toString() : "No messages for recipient.";
   }

       // Delete message by hash
     public static String deleteByHash(String hash) {
        for (int i = 0; i < totalMessages; i++) {
          if (messageHashes[i] != null && messageHashes[i].equals(hash)) {
            String deleted = sentMessages[i];
            sentMessages[i] = null;
            messageIDs[i] = null;
            messageHashes[i] = null;
            recipients[i] = null;
            return "Message deleted: \n" + deleted;
          }
      }
         return "Message hash not found.";
   }

        // Display report
      public static String displayReport() {
        StringBuilder sb = new StringBuilder("Sent Messages Report:\n");
         for (int i = 0; i < totalMessages; i++) {
           if (sentMessages[i] != null) {
            sb.append(sentMessages[i]).append("\n--------------------\n");
        }
    }
       return sb.toString();
   }

    @Override
    public String toString() {
        return "Message ID: " + messageID +
                "\nMessage Hash: " + createMessageHash() +
                "\nRecipient: " + recipient +
                "\nMessage: " + message;
    }

      
    
        
}
// ST10487025
// Thabang Kenneth Masango