package quickchatapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;

public class QuickChatApp {

    public static void main(String[] args) {
        // welcoming the user to the app

        Login user = null;

        while (true) {
            String option = JOptionPane.showInputDialog(
               null,
            "Welcome to QuickChat.\nChoose an option:\n1) Register\n2) Login\n3) Exit"
       );

       if (option == null) {
           return;
       }

      switch (option) {
        case "1": // Register
            String fname = JOptionPane.showInputDialog("Enter first name:");
              if (fname == null || fname.isEmpty()) {
                 continue;
          }

           String lname = JOptionPane.showInputDialog("Enter last name:");
            if (lname == null || lname.isEmpty()) {
               continue;
           }

       String username = JOptionPane.showInputDialog("Enter username:");
          if (username == null || username.isEmpty()) {
               continue;
          }

           JPasswordField passwordField = new JPasswordField();
            int passwordOption = JOptionPane.showConfirmDialog(null, passwordField, "Enter password", JOptionPane.OK_CANCEL_OPTION);
              if (passwordOption != JOptionPane.OK_OPTION) {
                  continue;
            }
         String password = new String(passwordField.getPassword());

             String phone = JOptionPane.showInputDialog("Enter SA phone number (e.g. +27713879295):");
               if (phone == null || phone.isEmpty()) {
                  continue;
          }

        user = new Login(username, password, phone, fname, lname);
           JOptionPane.showMessageDialog(null, user.registerUser());
            break;

         case "2": // Login
            if (user == null) {
             JOptionPane.showMessageDialog(null, "Please register first.");
              continue;
           }

         String loginUser = JOptionPane.showInputDialog("Enter your username to log in:");
            if (loginUser == null || loginUser.isEmpty()) {
               continue;
           }

      String loginPass = JOptionPane.showInputDialog("Enter your password:");
         if (loginPass == null || loginPass.isEmpty()) {
           continue;
        }

        if (!user.loginUser(loginUser, loginPass)) {
            JOptionPane.showMessageDialog(null, user.returnLoginStatus(false));
                continue;
         }

        JOptionPane.showMessageDialog(null, user.returnLoginStatus(true));

           // Sending messages
           int numMessages = Integer.parseInt(JOptionPane.showInputDialog("How many messages do you want to send?"));

              for (int i = 0; i < numMessages; i++) {
         String rec = JOptionPane.showInputDialog("Enter recipient number:");
         String msg = JOptionPane.showInputDialog("Enter message (max 250 characters):");

            if (msg.length() > 250) {
               JOptionPane.showMessageDialog(null, "Message exceeds 250 characters by " + (msg.length() - 250));
                   i--;
                   continue;
           }

       Message m = new Message(rec, msg);
       String[] options = {"Send", "Disregard", "Store"};
         int choice = JOptionPane.showOptionDialog(null, "Choose an action", "Message Option",
            JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

           boolean deleted = false;

         // Ask to delete only if "Disregard" was chosen
             if (choice == 1) { // Disregard
             int deleteChoice = JOptionPane.showConfirmDialog(null, "Do you want to delete this message?", "Delete Message", JOptionPane.YES_NO_OPTION);
             if (deleteChoice == JOptionPane.YES_OPTION) {
              JOptionPane.showMessageDialog(null, "Message deleted.");
                 deleted = true;
               } else {
                   JOptionPane.showMessageDialog(null, "Message kept.");
           }
       }

             // Only process the message if not deleted
            if (!deleted) {
               String result = m.sendMessageOption(choice + 1);
                 JOptionPane.showMessageDialog(null, result);

              // Show message details if "Send"
            if (choice == 0) {
                JOptionPane.showMessageDialog(null, m.toString());
          }
            }
        }

                    
          // Total sent
       JOptionPane.showMessageDialog(null, "Total messages sent: " + Message.returnTotalMessages());

         int viewReport = JOptionPane.showConfirmDialog(null, "Do you want to access the reporting features?", "Reports", JOptionPane.YES_NO_OPTION);
            if (viewReport == JOptionPane.YES_OPTION) {
                  showReports();
         }
        // Log out
         int logoutOption = JOptionPane.showConfirmDialog(null, "Do you want to log out?", "Logout", JOptionPane.YES_NO_OPTION);
           if (logoutOption == JOptionPane.YES_OPTION) {
               JOptionPane.showMessageDialog(null, "You have been logged out successfully.");
                   return;
             } else {
                 JOptionPane.showMessageDialog(null, "You are still logged in.");
          }
           break;

      case "3": // Exit
          JOptionPane.showMessageDialog(null, "Thank you for using QuickChat. Goodbye!");
             System.exit(0);
               break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please choose 1, 2, or 3.");
            }
        }
    
    }
        public static void showReports() {
          String[] options = {
              "1) Display All Sent",
              "2) Longest Message",
              "3) Search by Message ID",
              "4) Search by Recipient",
              "5) Delete by Hash",
              "6) Show Full Report",
              "7) Exit Reports"
         };

        while (true) {
            String choice = (String) JOptionPane.showInputDialog(
                    null,
                    "Select a report option:",
                    "Reports",
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            if (choice == null || choice.equals(options[6])) break;

            switch (choice) {
                case "1) Display All Sent":
                    JOptionPane.showMessageDialog(null, Message.printMessages());
                    break;
                case "2) Longest Message":
                    JOptionPane.showMessageDialog(null, Message.getLongestMessage());
                    break;
                case "3) Search by Message ID":
                    String id = JOptionPane.showInputDialog("Enter Message ID:");
                    JOptionPane.showMessageDialog(null, Message.searchByMessageID(id));
                    break;
                case "4) Search by Recipient":
                    String number = JOptionPane.showInputDialog("Enter Recipient Number:");
                    JOptionPane.showMessageDialog(null, Message.searchByRecipient(number));
                    break;
                case "5) Delete by Hash":
                    String hash = JOptionPane.showInputDialog("Enter Message Hash:");
                    JOptionPane.showMessageDialog(null, Message.deleteByHash(hash));
                    break;
                case "6) Show Full Report":
                    JOptionPane.showMessageDialog(null, Message.displayReport());
                    break;
            }
        }
    }

}
// ST10487025
// Thabang Kenneth Masango