/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import quickchatapp.Message;

/**
 *
 * @author RC_Student_lab
 */
public class MessageTest {
    Message message;
    public MessageTest() {
    }
    @BeforeEach
    public void setUp() {
        message = new Message("+27712285988", "Hello from QuickChat!");
    }

    @AfterEach
    public void tearDown() {
        message = null;
    }

    // ✅ Test message ID length (≤ 10 digits)
    @Test
    public void testCheckMessageID_Valid() {
        assertTrue(message.checkMessageID(), "Message ID should be valid (10 digits or fewer)");
    }

    // ✅ Test valid recipient cell number
    @Test
    public void testCheckRecipientCell_Valid() {
        assertTrue(message.checkRecipientCell(), "Recipient phone should be valid");
    }

    // ✅ Test invalid recipient number
    @Test
    public void testCheckRecipientCell_Invalid() {
        Message invalid = new Message("0831234567", "Hello!");
        assertFalse(invalid.checkRecipientCell(), "Phone number must start with +27 and be 12 digits long");
    }

    // ✅ Test hash creation
    @Test
    public void testCreateMessageHash_Format() {
        String hash = message.createMessageHash();
        assertTrue(hash.matches("^\\d{2}:\\d+:\\w+\\w+$"), "Hash should match format XX:Y:WORDWORD");
    }

    // ✅ Test message send (option 1)
    @Test
    public void testSendMessageOption_Send() {
        String result = message.sendMessageOption(1);
        assertEquals("Message successfully sent.", result);
        assertEquals(1, Message.returnTotalMessages());
    }

    // ✅ Test delete option (option 2)
    @Test
    public void testSendMessageOption_Delete() {
        String result = message.sendMessageOption(2);
        assertEquals("Press 0 to delete message.", result);
    }

    // ✅ Test store option (option 3)
    @Test
    public void testSendMessageOption_Store() {
        String result = message.sendMessageOption(3);
        assertEquals("Message successfully stored.", result);
    }

    // ✅ Test invalid option
    @Test
    public void testSendMessageOption_Invalid() {
        String result = message.sendMessageOption(5);
        assertEquals("Invalid option.", result);
    }

    // ✅ Test toString() method
    @Test
    public void testToString_NotNull() {
        String output = message.toString();
        assertNotNull(output);
        assertTrue(output.contains("Message ID:"));
    }

    // ✅ Test printMessages after sending
    @Test
    public void testPrintMessages() {
        message.sendMessageOption(1);
        String output = Message.printMessages();
        assertTrue(output.contains("Message ID:"));
    }

    // ✅ Test total messages count
    @Test
    public void testReturnTotalMessages() {
        int before = Message.returnTotalMessages();
        message.sendMessageOption(1);
        assertEquals(before + 1, Message.returnTotalMessages());
    }
   

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
// ST10487025
// Thabang Kenneth Masango